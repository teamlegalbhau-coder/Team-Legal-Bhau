# Team Legal Bhau Website

A free, mobile-friendly static website.

## Publish for free
1. Create a GitHub account.
2. Create a new public repository named `team-legal-bhau`.
3. Upload `index.html`.
4. Open Settings → Pages.
5. Select Deploy from branch → main → /(root).
6. Save. GitHub will provide your free website address.

## Before publishing
Replace:
- `your-email@example.com` with the real contact email.
- Sample blog cards with your actual links.
- The text/logo if you want your exact branding.

The site is intentionally built without paid libraries or hosting requirements.
